/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 *
 */

/***********************************************************************************************************************
* File Name    : Config_CAN0.c
* Version      : 1.3.0
* Device(s)    : R7F701650
* Description  : This file implements device driver for Config_CAN0.
***********************************************************************************************************************/
/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "Config_CAN_Reception.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
// Receive rule entry control register
#define RCFDCnCFDGAFLECTR    (*((volatile unsigned long *)(RCFDCn_base + 0x0098)))

// Receive rule ID register
#define RCFDCnCFDGAFLIDj(j)    (*((volatile unsigned long *)(RCFDCn_base + 0x1000 + j*0x0010)))

// Receive rule mask register
#define RCFDCnCFDGAFLMj(j)    (*((volatile unsigned long *)(RCFDCn_base + 0x1004 + j*0x0010)))

// Receive rule pointer 0 register
#define RCFDCnCFDGAFLP0_j(j)    (*((volatile unsigned long *)(RCFDCn_base + 0x1008 + j*0x0010)))

// Receive rule pointer 1 register
#define RCFDCnCFDGAFLP1_j(j)    (*((volatile unsigned long *)(RCFDCn_base + 0x100C + j*0x0010)))

// Receive buffer number register
#define RCFDCnCFDRMNB    (*((volatile unsigned long *)(RCFDCn_base + 0x00A4)))

// Receive buffer data register
#define RCFDCnCFDRMNDy(y)    (*((volatile unsigned long *)(RCFDCn_base + 0x00A8 + y*0x4)))

// Receive buffer ID register
#define RCFDCnCFDRMIDq(q)    (*((volatile unsigned long *)(RCFDCn_base + 0x2000 + q*0x80)))

// Receive buffer pointer register
#define RCFDCnCFDRMPTRq(q)    (*((volatile unsigned long *)(RCFDCn_base + 0x2004 + q*0x80)))

// Receive buffer CAN FD status register
#define RCFDCnCFDRMFDSTSq(q)    (*((volatile unsigned long *)(RCFDCn_base + 0x2008 + q*0x80)))

// Receive buffer data field register
#define RCFDCnCFDRMDFb_q(b, q)    (*((volatile unsigned long *)(RCFDCn_base + 0x200C + b*0x4 + q*0x80)))

// // Channel control register
#define RCFDCnCFDCmCTR(m)    (*((volatile unsigned long *)(RCFDCn_base + 0x0004 + m*0x10)))

// #define RCFDCnCFDGSTS    (*((volatile unsigned long *)(RCFDCn_base + 0x008C)))
#define RCFDCnCFDCmFDCFG(m)    (*((volatile unsigned long *)(RCFDCn_base + 0x0704 + m*0x20)))

// // Channel status register
#define RCFDCnCFDCmSTS(m)    (*((volatile unsigned long *)(RCFDCn_base + 0x0008 + m*0x10)))

// Channel nominal bit rate configuration register
#define RCFDCnCFDCmNCFG(m)    (*((volatile unsigned long *)(RCFDCn_base + 0x0000 + m*0x10)))

// Channel data bit rate configuration register
#define RCFDCnCFDCmDCFG(m)    (*((volatile unsigned long *)(RCFDCn_base + 0x0700 + m*0x20)))

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
// ET-VPF F1KM Product Version - V1.00.00 - Req. 01
// ID: ET_VPF_V1.00.00_CD_Req_02_013
// Reference: {ET_VPF_V1.00.00_UD_Req_02_001, ET_VPF_V1.00.00_UD_Req_02_002, ET_VPF_V1.00.00_UD_Req_02_003, ET_VPF_V1.00.00_UD_Req_02_004, ET_VPF_V1.00.00_UD_Req_02_005, ET_VPF_V1.00.00_UD_Req_02_006, ET_VPF_V1.00.00_UD_Req_02_007, ET_VPF_V1.00.00_UD_Req_02_008, ET_VPF_V1.00.00_UD_Req_02_009}
// Define the Reception ID for each CAN unit
char CAN0_RECV_ID = 0;
char CAN1_RECV_ID = 1;
char CAN2_RECV_ID = 2;
char CAN3_RECV_ID = 3;
char CAN4_RECV_ID = 4;
char CAN5_RECV_ID = 5;

// Define is extended ID for each CAN unit
long CAN0_Recv_isExtID = 0x0;
long CAN1_Recv_isExtID = 0x0;
long CAN2_Recv_isExtID = 0x0;
long CAN3_Recv_isExtID = 0x0;
long CAN4_Recv_isExtID = 0x0;
long CAN5_Recv_isExtID = 0x0;

// Define is remote frame for each CAN unit
long CAN0_Recv_isremote = 0x0;
long CAN1_Recv_isremote = 0x0;
long CAN2_Recv_isremote = 0x0;
long CAN3_Recv_isremote = 0x0;
long CAN4_Recv_isremote = 0x0;
long CAN5_Recv_isremote = 0x0;


/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_CAN0_Create
* Description  : This function initializes the Config_CAN0 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CAN_Common_Reception_Init(void)
{
    // Wait for RAM initialisation to finish
    while((RCFDCnCFDGSTS & 0x8) != 0x0);

    // Switch from global stop mode to global reset mode
    RCFDCnCFDGCTR = 0x1;
    while ((RCFDCnCFDGSTS & 0x1) == 0x0);

}

/***********************************************************************************************************************
* Function Name: R_Config_CAN0_Reception_Create
* Description  : This function initializes the Config_CAN0 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN0_Reception_Create(void)
{
    // Configure the CAN bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmNCFG(0) = (0x2 << 24) | (0x5 << 16); // NTSEG2 = 0x2, NTSEG1 = 0x5

    // Configure the CAN FD bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmDCFG(0) = (0x2 << 20) | (0x5 << 16); // DTSEG2 = 0x2, DTSEG1 = 5

    // Enable write to receive rule table; Page number 0
    RCFDCnCFDGAFLECTR = 0x00000100; 

    // List of rules are added
    
    // GFALIDE = CAN0_Recv_isExtID, GAFLRTR = CAN0_Recv_isremote, GAFLID = CAN0_RECV_ID
    RCFDCnCFDGAFLIDj(0) = CAN0_Recv_isExtID<<31 | CAN0_Recv_isremote<<30 | CAN0_RECV_ID; 

    RCFDCnCFDGAFLMj(0) = 0xC0000000 | 0x1FFFFFFF; // GAFLIDM = 0x1FFFFFFF
    RCFDCnCFDGAFLP0_j(0) = 0x00008000 | 0x8; // GAFLRMV=1, GAFLRMDP=0, DLC=8
    
    // Setting buffers
    RCFDCnCFDRMNB = 96; // RMPLS=0, NRXMB=2

    /*Using P0_1 - CAN0RX - Alternative mode In_7*/
    
    PORT.PMC0 |= SETBIT(1);
    PORT.PFCAE0 |= SETBIT(1);
    PORT.PFCE0 |= SETBIT(1);
    PORT.PFC0 &= CLEARBIT(1);
    PORT.PM0 &= CLEARBIT(1);

    R_Config_CAN0_Reception_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN1_Reception_Create
* Description  : This function initializes the Config_CAN1 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN1_Reception_Create(void)
{
    // Configure the CAN bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmNCFG(1) = (0x2 << 24) | (0x5 << 16); // NTSEG2 = 0x2, NTSEG1 = 0x5

    // Configure the CAN FD bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmDCFG(1) = (0x2 << 20) | (0x5 << 16); // DTSEG2 = 0x2, DTSEG1 = 5

    // Enable write to receive rule table; Page number 1
    RCFDCnCFDGAFLECTR = 0x00000101; 

    // List of rules are added
    // GFALIDE = CAN1_Recv_isExtID, GAFLRTR = CAN1_Recv_isremote, GAFLID = CAN1_RECV_ID
    RCFDCnCFDGAFLIDj(0) = CAN1_Recv_isExtID<<31 | CAN1_Recv_isremote<<30 | CAN1_RECV_ID;

    RCFDCnCFDGAFLMj(0) = 0xC0000000 | 0x1FFFFFFF; // GAFLIDM = 0x1FFFFFFF
    RCFDCnCFDGAFLP0_j(0) = 0x00008200 | 0x8; // GAFLRMV=1, GAFLRMDP=2, DLC=8
    
    // Setting buffers
    RCFDCnCFDRMNB = 96; // RMPLS=0, NRXMB=2

    /*Using P0_2 - CAN1RX - Alternative mode In_7*/
    
    PORT.PMC0 |= SETBIT(2);
    PORT.PFCAE0 |= SETBIT(2);
    PORT.PFCE0 |= SETBIT(2);
    PORT.PFC0 &= CLEARBIT(2);
    PORT.PM0 &= CLEARBIT(2);
    
    R_Config_CAN1_Reception_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN2_Reception_Create
* Description  : This function initializes the Config_CAN1 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN2_Reception_Create(void)
{
    // Configure the CAN bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmNCFG(2) = (0x2 << 24) | (0x5 << 16); // NTSEG2 = 0x2, NTSEG1 = 0x5

    // Configure the CAN FD bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmDCFG(2) = (0x2 << 20) | (0x5 << 16); // DTSEG2 = 0x2, DTSEG1 = 5

    // Enable write to receive rule table; Page number 2
    RCFDCnCFDGAFLECTR = 0x00000102; 

    // List of rules are added
    // GFALIDE = CAN2_Recv_isExtID, GAFLRTR = CAN2_Recv_isremote, GAFLID = CAN2_RECV_ID
    RCFDCnCFDGAFLIDj(0) = CAN2_Recv_isExtID<<31 | CAN2_Recv_isremote<<30 | CAN2_RECV_ID;

    RCFDCnCFDGAFLMj(0) = 0xC0000000 | 0x1FFFFFFF; // GAFLIDM = 0x1FFFFFFF
    RCFDCnCFDGAFLP0_j(0) = 0x00008400 | 0x8; // GAFLRMV=1, GAFLRMDP=4, DLC=8

    // Setting buffers
    RCFDCnCFDRMNB = 96; // RMPLS=0, NRXMB=2

    /*Using P0_5 - CAN2RX - Alternative mode In_7*/
    
    PORT.PMC0 |= SETBIT(5);
    PORT.PFCAE0 |= SETBIT(5);
    PORT.PFCE0 |= SETBIT(5);
    PORT.PFC0 &= CLEARBIT(5);
    PORT.PM0 &= CLEARBIT(5);

    R_Config_CAN2_Reception_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN3_Reception_Create
* Description  : This function initializes the Config_CAN3 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN3_Reception_Create(void)
{
    // Configure the CAN bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmNCFG(3) = (0x2 << 24) | (0x5 << 16); // NTSEG2 = 0x2, NTSEG1 = 0x5

    // Configure the CAN FD bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmDCFG(3) = (0x2 << 20) | (0x5 << 16); // DTSEG2 = 0x2, DTSEG1 = 5

    // Enable write to receive rule table; Page number 3
    RCFDCnCFDGAFLECTR = 0x00000103;

    // List of rules are added
    // GFALIDE = CAN3_Recv_isExtID, GAFLRTR = CAN3_Recv_isremote, GAFLID = CAN3_RECV_ID
    RCFDCnCFDGAFLIDj(0) = CAN3_Recv_isExtID<<31 | CAN3_Recv_isremote<<30 | CAN3_RECV_ID;

    RCFDCnCFDGAFLMj(0) = 0xC0000000 | 0x1FFFFFFF; // GAFLIDM = 0x1FFFFFFF
    RCFDCnCFDGAFLP0_j(0) = 0x00008600 | 0x8; // GAFLRMV=1, GAFLRMDP=4, DLC=8

    // Setting buffers
    RCFDCnCFDRMNB = 96; // RMPLS=0, NRXMB=2

    /*Using P0_7 - CAN3RX - Alternative mode In_7*/
    
    PORT.PMC0 |= SETBIT(7);
    PORT.PFCAE0 |= SETBIT(7);
    PORT.PFCE0 |= SETBIT(7);
    PORT.PFC0 &= CLEARBIT(7);
    PORT.PM0 &= CLEARBIT(7);

    R_Config_CAN3_Reception_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN4_Reception_Create
* Description  : This function initializes the Config_CAN3 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN4_Reception_Create(void)
{
    // Configure the CAN bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmNCFG(4) = (0x2 << 24) | (0x5 << 16); // NTSEG2 = 0x2, NTSEG1 = 0x5

    // Configure the CAN FD bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmDCFG(4) = (0x2 << 20) | (0x5 << 16); // DTSEG2 = 0x2, DTSEG1 = 5

    // Enable write to receive rule table; Page number 4
    RCFDCnCFDGAFLECTR = 0x00000104; 

    // List of rules are added
    // GFALIDE = CAN4_Recv_isExtID, GAFLRTR = CAN4_Recv_isremote, GAFLID = CAN4_RECV_ID
    RCFDCnCFDGAFLIDj(0) = CAN4_Recv_isExtID<<31 | CAN4_Recv_isremote<<30 | CAN4_RECV_ID;

    RCFDCnCFDGAFLMj(0) = 0xC0000000 | 0x1FFFFFFF; // GAFLIDM = 0x1FFFFFFF
    RCFDCnCFDGAFLP0_j(0) = 0x00008800 | 0x8; // GAFLRMV=1, GAFLRMDP=8, DLC=8

    // Setting buffers
    RCFDCnCFDRMNB = 96; // RMPLS=0, NRXMB=2
    
    /*Using P0_9 - CAN4RX - Alternative mode In_7*/
    
    PORT.PMC0 |= SETBIT(9);
    PORT.PFCAE0 |= SETBIT(9);
    PORT.PFCE0 |= SETBIT(9);
    PORT.PFC0 &= CLEARBIT(9);
    PORT.PM0 &= CLEARBIT(9);

    R_Config_CAN4_Reception_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN5_Reception_Create
* Description  : This function initializes the Config_CAN3 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN5_Reception_Create(void)
{
    // Configure the CAN bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmNCFG(5) = (0x2 << 24) | (0x5 << 16); // NTSEG2 = 0x2, NTSEG1 = 0x5

    // Configure the CAN FD bit timing for channel
    // The bit rate is 1000 kb/s
    // the nominal bit time is 1 + 6 + 3 Tq = 10 Tq. (tseg1=5, tseg2=2,sjw=0, brp = 0)
    // The clock is 4 Mhz / brp+1 = 4 Mhz, so we get a bit rate of 4 / 10 = 100000 Hz.
    RCFDCnCFDCmDCFG(5) = (0x2 << 20) | (0x5 << 16); // DTSEG2 = 0x2, DTSEG1 = 5

    // Enable write to receive rule table; Page number 5
    RCFDCnCFDGAFLECTR = 0x00000105; 

    // List of rules are added
    // GFALIDE = CAN5_Recv_isExtID, GAFLRTR = CAN5_Recv_isremote, GAFLID = CAN5_RECV_ID
    RCFDCnCFDGAFLIDj(0) = CAN5_Recv_isExtID<<31 | CAN5_Recv_isremote<<30 | CAN5_RECV_ID;
    
    RCFDCnCFDGAFLMj(0) = 0xC0000000 | 0x1FFFFFFF; // GAFLIDM = 0x1FFFFFFF
    RCFDCnCFDGAFLP0_j(0) = 0x00008A00 | 0x8; // GAFLRMV=1, GAFLRMDP=A, DLC=8

    // Setting buffers
    RCFDCnCFDRMNB = 96; // RMPLS=0, NRXMB=2

    /*Using P0_13 - CAN5RX - Alternative mode In_7*/
    
    PORT.PMC0 |= SETBIT(13);
    PORT.PFCAE0 |= SETBIT(13);
    PORT.PFCE0 |= SETBIT(13);
    PORT.PFC0 &= CLEARBIT(13);
    PORT.PM0 &= CLEARBIT(13);
    
    R_Config_CAN5_Reception_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN0_Start
* Description  : This function starts the Config_CAN0 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN0_Reception_Start(void)
{
    //Change channel 1 to communication mode
    RCFDCnCFDCmCTR(0) = 0x0;
    while ((RCFDCnCFDCmSTS(0) & 0x80) == 0x0);
    // Using classical CAN 
    RCFDCnCFDCmFDCFG(0) = 0x40000000;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN1_Start
* Description  : This function starts the Config_CAN1 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN1_Reception_Start(void)
{

    //Change channel 1 to communication mode
    RCFDCnCFDCmCTR(1) = 0x0;
    while ((RCFDCnCFDCmSTS(1) & 0x80) == 0x0);
    // Using classical CAN 
    RCFDCnCFDCmFDCFG(1) = 0x40000000;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN2_Start
* Description  : This function starts the Config_CAN2 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN2_Reception_Start(void)
{

    //Change channel 1 to communication mode
    RCFDCnCFDCmCTR(2) = 0x0;
    while ((RCFDCnCFDCmSTS(2) & 0x80) == 0x0);
    // Using classical CAN 
    RCFDCnCFDCmFDCFG(2) = 0x40000000;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN3_Start
* Description  : This function starts the Config_CAN3 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN3_Reception_Start(void)
{
    //Change channel 1 to communication mode
    RCFDCnCFDCmCTR(3) = 0x0;
    while ((RCFDCnCFDCmSTS(3) & 0x80) == 0x0);
    // Using classical CAN 
    RCFDCnCFDCmFDCFG(3) = 0x40000000;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN4_Start
* Description  : This function starts the Config_CAN4 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN4_Reception_Start(void)
{
    //Change channel 1 to communication mode
    RCFDCnCFDCmCTR(4) = 0x0;
    while ((RCFDCnCFDCmSTS(4) & 0x80) == 0x0);
    // Using classical CAN 
    RCFDCnCFDCmFDCFG(4) = 0x40000000;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN5_Start
* Description  : This function starts the Config_CAN5 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN5_Reception_Start(void)
{


    //Change channel 1 to communication mode
    RCFDCnCFDCmCTR(5) = 0x0;
    while ((RCFDCnCFDCmSTS(5) & 0x80) == 0x0);
    // Using classical CAN 
    RCFDCnCFDCmFDCFG(5) = 0x40000000;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN0_Transmission_Stop
* Description  : This function stops the CAN0 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN0_Reception_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC0CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN1_Transmission_Stop
* Description  : This function stops the CAN1 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN1_Reception_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC1CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN2_Transmission_Stop
* Description  : This function stops the CAN2 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN2_Reception_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC2CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN3_Transmission_Stop
* Description  : This function stops the CAN3 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN3_Reception_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC3CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN4_Transmission_Stop
* Description  : This function stops the CAN4 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN4_Reception_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC4CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}


/***********************************************************************************************************************
* Function Name: R_Config_CAN5_Transmission_Stop
* Description  : This function stops the CAN5 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN5_Reception_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC5CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN_Receive
* Description  : This function receive CAN data.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
MD_STATUS R_Config_CAN_Receive( char unit, char channel, uint8_t * output)
{
    volatile long long data;
    volatile long long lowerData;
    volatile long long upperData;
    uint16_t msgLength;

    
    while (0 == RCFDCnCFDRMNDy(0));
    if (RCFDCnCFDRMNDy(0) & (1 << channel*2))
    {
        // Clear the flag
        RCFDCnCFDRMNDy(0) = RCFDCnCFDRMNDy(0) & ~(1 << channel*2);
        // Read the data
 
        lowerData = RCFDCnCFDRMDFb_q(0,channel *2);
        upperData = RCFDCnCFDRMDFb_q(1,channel *2);

        data = (upperData<<32) | lowerData;
        msgLength = (RCFDCnCFDRMPTRq(channel*2) & 0xF0000000) >>28; //RMDLC[3:0] bit 31-28
        for (int i = 0; i <= msgLength; i++){
            output[i] = (uint8_t) (data & 0xFF); // get 1 byte and add to the array
            data = data>>8;
        }
    }
    return 0;
}

// ET-VPF F1KM Product Version - V1.00.00 - Req. 02 - End
/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
