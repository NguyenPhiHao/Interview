#
# Copyright(C) 2022 Renesas Electronics Corporation
# RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
# This program must be used solely for the purpose for which
# it was furnished by Renesas Electronics Corporation. No part of this
# program may be reproduced or disclosed to others, in any
# form, without the prior written permission of Renesas Electronics
# Corporation.
#

import sysc
import can
from can.CANNode import CANNode
from can.Frame import Frame as Frame
import global_database

class tx_trigger(sysc.sc_module, CANNode):
    """Transmits a frame when an input port is triggered."""

    def __init__(self, name):
        sysc.sc_module.__init__(self, name)
        CANNode.__init__(self, "node", can.CANNode.ENGINE_TYPE_TOKEN)

        self.TRIGGER = sysc.sc_in_sc_logic("TRIGGER")

        # Spawn transmit method when TRIGGER input changes
        self.spawn_method("transmit_method0", self.TRIGGER, True)

    # Define the transmit threads
    def transmit_method0(self):
        #print self.name(), ": transmit_method0 is started"
        # ET-VPF F1KM Product Version - V1.00.00 - Req. 02
        # ID: ET_VPF_V1.00.00_CD_Req_02_015
        # Reference: {ET_VPF_V1.00.00_UD_Req_02_001, ET_VPF_V1.00.00_UD_Req_02_002, ET_VPF_V1.00.00_UD_Req_02_003, ET_VPF_V1.00.00_UD_Req_02_004, ET_VPF_V1.00.00_UD_Req_02_005, ET_VPF_V1.00.00_UD_Req_02_006, ET_VPF_V1.00.00_UD_Req_02_007, ET_VPF_V1.00.00_UD_Req_02_008, ET_VPF_V1.00.00_UD_Req_02_009}
        if type(global_database.data) is tuple:
                test_list = [int(i) for i in list(global_database.data[0])]
        else:
                test_list = [global_database.data]
        frame = Frame(Frame.FRAME_TYPE_MESSAGE, global_database.isRemote, global_database.isExt, global_database.id, len(test_list))
        frame.set_data(test_list)
        #print self.name(), ": Transmitting a trigger frame.", frame.show()
        self.transmit_frame(frame)
        # ET-VPF F1KM Product Version - V1.00.00 - Req. 02 - End
