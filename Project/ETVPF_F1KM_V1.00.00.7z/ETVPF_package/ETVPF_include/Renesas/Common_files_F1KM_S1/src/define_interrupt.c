/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 *
 */
 
/***********************************************************************************************************************
* File Name    : r_cg_intvector_PE0.c
* Version      : 1.0.101
* Device(s)    : R7F701685
* Description  : None
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/

/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
void FEINT_PE0(void){}
/* Reserved; */
void eiint0(void){}
/* Reserved; */
void eiint1(void){}
/* Reserved; */
void eiint2(void){}
/* Reserved; */
void eiint3(void){}
/* Reserved; */
void eiint4(void){}
/* Reserved; */
void eiint5(void){}
/* Reserved; */
void eiint6(void){}
/* Reserved; */
void eiint7(void){}
/* Interrupt for CH0 of TAUD0; */
void eiint8(void){}
/* Interrupt for CH2 of TAUD0; */
void eiint9(void){}
/* Interrupt for CH4 of TAUD0; */
void eiint10(void){}
/* Interrupt for CH6 of TAUD0; */
void eiint11(void){}
/* Interrupt for CH8 of TAUD0; */
void eiint12(void){}
/* Interrupt for CH10 of TAUD0; */
void eiint13(void){}
/* Interrupt for CH12 of TAUD0; */
void eiint14(void){}
/* Interrupt for CH14 of TAUD0; */
void eiint15(void){}
/* TAPA0 peak interrupt 0; */
void eiint16(void){}
/* TAPA0 valley interrupt 0; */
void eiint17(void){}
/* ADCA0 SG1 end interrupt; */
void eiint18(void){}
/* ADCA0 SG2 end interrupt; */
void eiint19(void){}
/* ADCA0 SG3 end interrupt; */
void eiint20(void){}
/* Dedicated interrupt for on-chip debug function; */
void eiint21(void){}
/* CAN global error interrupt; */
void eiint22(void){}
/* CAN receive FIFO interrupt; */
void eiint23(void){}
/* CAN0 error interrupt; */
void eiint24(void){}
/* CAN0 transmit/receive FIFO receive complete interrupt; */
void eiint25(void){}
/* CAN0 transmit interrupt; */
void eiint26(void){}
/* CSIG0 communication status interrupt; */
void eiint27(void){}
/* CSIG0 receive status interrupt; */
void eiint28(void){}
/* CSIH0 communication status interrupt; */
void eiint29(void){}
/* CSIH0 receive status interrupt; */
void eiint30(void){}
/* CSIH0 communication error interrupt; */
void eiint31(void){}
/* CSIH0 job completion interrupt; */
void eiint32(void){}
/* RLIN30 interrupt; */
void eiint33(void){}
/* RLIN30 transmit interrupt; */
void eiint34(void){}
/* RLIN30 receive complete interrupt; */
void eiint35(void){}
/* RLIN30 status interrupt; */
void eiint36(void){}
/* __interruptal interrupt; */
void eiint37(void){}
/* __interruptal interrupt; */
void eiint38(void){}
/* __interruptal interrupt; */
void eiint39(void){}
/* WDTA0 75% interrupt; */
void eiint40(void){}
/* WDTA1 75% interrupt; */
void eiint41(void){}
/* Reserved; */
void eiint42(void){}
/* __interruptal interrupt; */
void eiint43(void){}
/* __interruptal interrupt; */
void eiint44(void){}
/* __interruptal interrupt; */
void eiint45(void){}
/* __interruptal interrupt; */
void eiint46(void){}
/* __interruptal interrupt; */
void eiint47(void){}
/* Interrupt for TAUD0 channel 1; */
void eiint48(void){}
/* Interrupt for TAUD0 channel 3; */
void eiint49(void){}
/* Interrupt for TAUD0 channel 5; */
void eiint50(void){}
/* Interrupt for TAUD0 channel 7; */
void eiint51(void){}
/* Interrupt for TAUD0 channel 9; */
void eiint52(void){}
/* Interrupt for TAUD0 channel 11; */
void eiint53(void){}
/* Interrupt for TAUD0 channel 13; */
void eiint54(void){}
/* Interrupt for TAUD0 channel 15; */
void eiint55(void){}
/* ADCA0 error interrupt; */
void eiint56(void){}
/* CSIG0 communication error interrupt; */
void eiint57(void){}
/* RLIN20 interrupt; */
void eiint58(void){}
/* RLIN21 interrupt; */
void eiint59(void){}
/* DMA00 transfer completion; */
void eiint60(void){}
/* DMA01 transfer completion; */
void eiint61(void){}
/* DMA02 transfer completion; */
void eiint62(void){}
/* DMA03 transfer completion; */
void eiint63(void){}
/* DMA04 transfer completion; */
void eiint64(void){}
/* DMA05 transfer completion; */
void eiint65(void){}
/* DMA06 transfer completion; */
void eiint66(void){}
/* DMA07 transfer completion; */
void eiint67(void){}
/* DMA10 transfer completion; */
void eiint68(void){}
/* DMA11 transfer completion; */
void eiint69(void){}
/* DMA12 transfer completion; */
void eiint70(void){}
/* DMA13 transfer completion; */
void eiint71(void){}
/* DMA14 transfer completion; */
void eiint72(void){}
/* DMA15 transfer completion; */
void eiint73(void){}
/* DMA16 transfer completion; */
void eiint74(void){}
/* DMA17 transfer completion; */
void eiint75(void){}
/* RIIC0 transmit data empty interrupt; */
void eiint76(void){}
/* RIIC0 receive error/event interrupt; */
void eiint77(void){}
/* RIIC0 receive complete interrupt; */
void eiint78(void){}
/* RIIC0 transmit complete interrupt; */
void eiint79(void){}
/* Interrupt for TAUJ0 channel 0; */
void eiint80(void){}
/* Interrupt for TAUJ0 channel 1; */
void eiint81(void){}
/* Interrupt for TAUJ0 channel 2; */
void eiint82(void){}
/* Interrupt for TAUJ0 channel 3; */
void eiint83(void){}
/* OSTM0 interrupt; */
//void eiint84(void){}
/* ENCA0 overflow interrupt; */
void eiint85(void){}
/* ENCA0 underflow interrupt; */
void eiint86(void){}
/* ENCA0 match/capture interrupt 0; */
void eiint87(void){}
/* ENCA0 match/capture interrupt 1; */
void eiint88(void){}
/* ENCA0 encoder clear interrupt; */
void eiint89(void){}
/* KR0 key interrupt; */
void eiint90(void){}
/* PWSA0 queue full interrupt; */
void eiint91(void){}
/* PWGA interrupt group 00 (PWGA0 to PWGA31){} */
void eiint92(void){}
/* PWGA interrupt group 01 (PWGA32 to PWGA63){} */
void eiint93(void){}
/* PWGA interrupt group 02 (PWGA64 to PWGA95){} */
void eiint94(void){}
/* Reserved; */
void eiint95(void){}
/* Reserved; */
void eiint96(void){}
/* Reserved; */
void eiint97(void){}
/* Reserved; */
void eiint98(void){}
/* Reserved; */
void eiint99(void){}
/* Reserved; */
void eiint100(void){}
/* Reserved; */
void eiint101(void){}
/* Reserved; */
void eiint102(void){}
/* Reserved; */
void eiint103(void){}
/* Reserved; */
void eiint104(void){}
/* Reserved; */
void eiint105(void){}
/* Reserved; */
void eiint106(void){}
/* Reserved; */
void eiint107(void){}
/* Reserved; */
void eiint108(void){}
/* Reserved; */
void eiint109(void){}
/* Flash sequencer end error interrupt; */
void eiint110(void){}
/* Flash sequencer end interrupt; */
void eiint111(void){}
/* LPS0 port polling end interrupt; */
void eiint112(void){}
/* CAN1 error interrupt; */
void eiint113(void){}
/* CAN1 transmit/receive FIFO receive complete interrupt; */
void eiint114(void){}
/* CAN1 transmit interrupt; */
void eiint115(void){}
/* CSIH1 communication status interrupt; */
void eiint116(void){}
/* CSIH1 receive status interrupt; */
void eiint117(void){}
/* CSIH1 communication error interrupt; */
void eiint118(void){}
/* CSIH1 job completion interrupt; */
void eiint119(void){}
/* RLIN31 interrupt; */
void eiint120(void){}
/* RLIN31 transmit interrupt; */
void eiint121(void){}
/* RLIN31 receive complete interrupt; */
void eiint122(void){}
/* RLIN31 status interrupt; */
void eiint123(void){}
/* Reserved; */
void eiint124(void){}
/* Reserved; */
void eiint125(void){}
/* Reserved; */
void eiint126(void){}
/* Reserved; */
void eiint127(void){}
/* __interruptal interrupt; */
void eiint128(void){}
/* __interruptal interrupt; */
void eiint129(void){}
/* __interruptal interrupt; */
void eiint130(void){}
/* __interruptal interrupt; */
void eiint131(void){}
/* CSIH2 communication status interrupt; */
void eiint132(void){}
/* CSIH2 receive status interrupt; */
void eiint133(void){}
/* CSIH2 communication error interrupt; */
void eiint134(void){}
/* CSIH2 job completion interrupt; */
void eiint135(void){}
/* Reserved; */
void eiint136(void){}
/* Reserved; */
void eiint137(void){}
/* Reserved; */
void eiint138(void){}
/* Reserved; */
void eiint139(void){}
/* Reserved; */
void eiint140(void){}
/* Reserved; */
void eiint141(void){}
/* Interrupt for TAUB0 channel 0; */
void eiint142(void){}
/* Interrupt for TAUB0 channel 1; */
void eiint143(void){}
/* Interrupt for TAUB0 channel 2; */
void eiint144(void){}
/* Interrupt for TAUB0 channel 3; */
void eiint145(void){}
/* Interrupt for TAUB0 channel 4; */
void eiint146(void){}
/* Interrupt for TAUB0 channel 5; */
void eiint147(void){}
/* Interrupt for TAUB0 channel 6; */
void eiint148(void){}
/* Interrupt for TAUB0 channel 7; */
void eiint149(void){}
/* Interrupt for TAUB0 channel 8; */
void eiint150(void){}
/* Interrupt for TAUB0 channel 9; */
void eiint151(void){}
/* Interrupt for TAUB0 channel 10; */
void eiint152(void){}
/* Interrupt for TAUB0 channel 11; */
void eiint153(void){}
/* Interrupt for TAUB0 channel 12; */
void eiint154(void){}
/* Interrupt for TAUB0 channel 13; */
void eiint155(void){}
/* Interrupt for TAUB0 channel 14; */
void eiint156(void){}
/* Interrupt for TAUB0 channel 15; */
void eiint157(void){}
/* CSIH3 communication status interrupt; */
void eiint158(void){}
/* CSIH3 receive status interrupt; */
void eiint159(void){}
/* CSIH3 communication error interrupt; */
void eiint160(void){}
/* CSIH3 job completion interrupt; */
void eiint161(void){}
/* RLIN22 interrupt; */
void eiint162(void){}
/* RLIN23 interrupt; */
void eiint163(void){}
/* RLIN32 interrupt; */
void eiint164(void){}
/* RLIN32 transmit interrupt; */
void eiint165(void){}
/* RLIN32 receive complete interrupt; */
void eiint166(void){}
/* RLIN32 status interrupt; */
void eiint167(void){}
/* Interrupt for TAUJ1 channel 0; */
void eiint168(void){}
/* Interrupt for TAUJ1 channel 1; */
void eiint169(void){}
/* Interrupt for TAUJ1 channel 2; */
void eiint170(void){}
/* Interrupt for TAUJ1 channel 3; */
void eiint171(void){}
/* Reserved; */
void eiint172(void){}
/* FIFO transfer interrupt; */
void eiint173(void){}
/* FIFO transfer warning interrupt; */
void eiint174(void){}
/* Input queue empty interrupt; */
void eiint175(void){}
/* Input queue full interrupt; */
void eiint176(void){}
/* Output transfer end interrupt; */
void eiint177(void){}
/* Output transfer warning interrupt; */
void eiint178(void){}
/* FlexRay0 interrupt; */
void eiint179(void){}
/* FlexRay1 interrupt; */
void eiint180(void){}
/* Timer 0 interrupt; */
void eiint181(void){}
/* Timer 1 interrupt; */
void eiint182(void){}
/* Timer 2 interrupt; */
void eiint183(void){}
/* Reserved; */
void eiint184(void){}
/* Reserved; */
void eiint185(void){}
/* Reserved; */
void eiint186(void){}
/* Reserved; */
void eiint187(void){}
/* Reserved; */
void eiint188(void){}
/* Reserved; */
void eiint189(void){}
/* Reserved; */
void eiint190(void){}
/* Reserved; */
void eiint191(void){}
/* Reserved; */
void eiint192(void){}
/* Reserved; */
void eiint193(void){}
/* Reserved; */
void eiint194(void){}
/* Reserved; */
void eiint195(void){}
/* Reserved; */
void eiint196(void){}
/* Reserved; */
void eiint197(void){}
/* Reserved; */
void eiint198(void){}
/* Reserved; */
void eiint199(void){}
/* Reserved; */
void eiint200(void){}
/* Reserved; */
void eiint201(void){}
/* Reserved; */
void eiint202(void){}
/* Reserved; */
void eiint203(void){}
/* Reserved; */
void eiint204(void){}
/* __interruptal interrupt; */
void eiint205(void){}
/* __interruptal interrupt; */
void eiint206(void){}
/* __interruptal interrupt; */
void eiint207(void){}
/* __interruptal interrupt; */
void eiint208(void){}
/* RTCA0 1-second interval interrupt; */
void eiint209(void){}
/* RTCA0 alarm interrupt; */
void eiint210(void){}
/* RTCA0 fixed interval interrupt; */
void eiint211(void){}
/* ADCA1 error interrupt; */
void eiint212(void){}
/* ADCA1 scan group 1 (SG1) end interrupt; */
void eiint213(void){}
/* ADCA1 scan group 2 (SG2) end interrupt; */
void eiint214(void){}
/* ADCA1 scan group 3 (SG3) end interrupt; */
void eiint215(void){}
/* Reserved; */
void eiint216(void){}
/* CAN2 error interrupt; */
void eiint217(void){}
/* CAN2 transmit/receive FIFO receive complete interrupt; */
void eiint218(void){}
/* CAN2 transmit interrupt; */
void eiint219(void){}
/* CAN3 error interrupt; */
void eiint220(void){}
/* CAN3 transmit/receive FIFO receive complete interrupt; */
void eiint221(void){}
/* CAN3 transmit interrupt; */
void eiint222(void){}
/* CSIG1 communication status interrupt; */
void eiint223(void){}
/* CSIG1 receive status interrupt; */
void eiint224(void){}
/* CSIG1 communication error interrupt; */
void eiint225(void){}
/* RLIN24 interrupt; */
void eiint226(void){}
/* RLIN25 interrupt; */
void eiint227(void){}
/* RLIN33 interrupt; */
void eiint228(void){}
/* RLIN33 transmit interrupt; */
void eiint229(void){}
/* RLIN33 receive complete interrupt; */
void eiint230(void){}
/* RLIN33 status interrupt; */
void eiint231(void){}
/* RLIN34 interrupt; */
void eiint232(void){}
/* RLIN34 transmit interrupt; */
void eiint233(void){}
/* RLIN34 receive complete interrupt; */
void eiint234(void){}
/* RLIN34 status interrupt; */
void eiint235(void){}
/* RLIN35 interrupt; */
void eiint236(void){}
/* RLIN35 transmit interrupt; */
void eiint237(void){}
/* RLIN35 receive complete interrupt; */
void eiint238(void){}
/* RLIN35 status interrupt; */
void eiint239(void){}
/* RIIC1 transmit data empty interrupt; */
void eiint240(void){}
/* RIIC1 receive error/event interrupt; */
void eiint241(void){}
/* RIIC1 receive complete interrupt; */
void eiint242(void){}
/* RIIC1 transmit complete interrupt; */
void eiint243(void){}
/* Reserved; */
void eiint244(void){}
/* Reserved; */
void eiint245(void){}
/* Reserved; */
void eiint246(void){}
/* Reserved; */
void eiint247(void){}
/* Reserved; */
void eiint248(void){}
/* Reserved; */
void eiint249(void){}
/* Reserved; */
void eiint250(void){}
/* Reserved; */
void eiint251(void){}
/* Reserved; */
void eiint252(void){}
/* Reserved; */
void eiint253(void){}
/* Reserved; */
void eiint254(void){}
/* Reserved; */
void eiint255(void){}
/* Interrupt for TAUB1 channel 0; */
void eiint256(void){}
/* Interrupt for TAUB1 channel 1; */
void eiint257(void){}
/* Interrupt for TAUB1 channel 2; */
void eiint258(void){}
/* Interrupt for TAUB1 channel 3; */
void eiint259(void){}
/* Interrupt for TAUB1 channel 4; */
void eiint260(void){}
/* Interrupt for TAUB1 channel 5; */
void eiint261(void){}
/* Interrupt for TAUB1 channel 6; */
void eiint262(void){}
/* Interrupt for TAUB1 channel 7; */
void eiint263(void){}
/* Interrupt for TAUB1 channel 8; */
void eiint264(void){}
/* Interrupt for TAUB1 channel 9; */
void eiint265(void){}
/* Interrupt for TAUB1 channel 10; */
void eiint266(void){}
/* Interrupt for TAUB1 channel 11; */
void eiint267(void){}
/* Interrupt for TAUB1 channel 12; */
void eiint268(void){}
/* Interrupt for TAUB1 channel 13; */
void eiint269(void){}
/* Interrupt for TAUB1 channel 14; */
void eiint270(void){}
/* Interrupt for TAUB1 channel 15; */
void eiint271(void){}
/* CAN4 error interrupt; */
void eiint272(void){}
/* CAN4 transmit/receive FIFO receive complete interrupt; */
void eiint273(void){}
/* CAN4 transmit interrupt; */
void eiint274(void){}
/* RLIN26 interrupt; */
void eiint275(void){}
/* RLIN27 interrupt; */
void eiint276(void){}
/* Interrupt for TAUJ2 channel 0; */
void eiint277(void){}
/* Interrupt for TAUJ2 channel 1; */
void eiint278(void){}
/* Interrupt for TAUJ2 channel 2; */
void eiint279(void){}
/* Interrupt for TAUJ2 channel 3; */
void eiint280(void){}
/* Interrupt for TAUJ3 channel 0; */
void eiint281(void){}
/* Interrupt for TAUJ3 channel 1; */
void eiint282(void){}
/* Interrupt for TAUJ3 channel 2; */
void eiint283(void){}
/* Interrupt for TAUJ3 channel 3; */
void eiint284(void){}
/* RLIN28 interrupt; */
void eiint285(void){}
/* RLIN29 interrupt; */
void eiint286(void){}
/* CAN5 error interrupt; */
void eiint287(void){}
/* CAN5 transmit/receive FIFO receive complete interrupt; */
void eiint288(void){}
/* CAN5 transmit interrupt; */
void eiint289(void){}
/* Reserved; */
void eiint290(void){}
/* Reserved; */
void eiint291(void){}
/* Reserved; */
void eiint292(void){}
/* Reserved; */
void eiint293(void){}
/* Reserved; */
void eiint294(void){}
/* Reserved; */
void eiint295(void){}
/* Reserved; */
void eiint296(void){}
/* Reserved; */
void eiint297(void){}
/* DMA20 transfer completion; */
void eiint298(void){}
/* DMA21 transfer completion; */
void eiint299(void){}
/* DMA22 transfer completion; */
void eiint300(void){}
/* DMA23 transfer completion; */
void eiint301(void){}
/* DMA24 transfer completion; */
void eiint302(void){}
/* DMA25 transfer completion; */
void eiint303(void){}
/* DMA26 transfer completion; */
void eiint304(void){}
/* DMA27 transfer completion; */
void eiint305(void){}
/* DMA30 transfer completion; */
void eiint306(void){}
/* DMA31 transfer completion; */
void eiint307(void){}
/* DMA32 transfer completion; */
void eiint308(void){}
/* DMA33 transfer completion; */
void eiint309(void){}
/* DMA34 transfer completion; */
void eiint310(void){}
/* DMA35 transfer completion; */
void eiint311(void){}
/* DMA36 transfer completion; */
void eiint312(void){}
/* DMA37 transfer completion; */
void eiint313(void){}
/* Reserved; */
void eiint314(void){}
/* Data related interrupt; */
void eiint315(void){}
/* Error related interrupt; */
void eiint316(void){}
/* Management related interrupt; */
void eiint317(void){}
/* MAC interrupt; */
void eiint318(void){}
/* Reserved; */
void eiint319(void){}
/* Reserved; */
void eiint320(void){}
/* CAN6 error interrupt; */
void eiint321(void){}
/* CAN6 transmit/receive FIFO receive complete interrupt; */
void eiint322(void){}
/* CAN6 transmit interrupt; */
void eiint323(void){}
/* RLIN210 interrupt; */
void eiint324(void){}
/* RLIN211 interrupt; */
void eiint325(void){}
/* CSIG2 communication status interrupt; */
void eiint326(void){}
/* CSIG2 receive status interrupt; */
void eiint327(void){}
/* CSIG2 communication error interrupt; */
void eiint328(void){}
/* CSIG3 communication status interrupt; */
void eiint329(void){}
/* CSIG3 receive status interrupt; */
void eiint330(void){}
/* CSIG3 communication error interrupt; */
void eiint331(void){}
/* CAN7 error interrupt; */
void eiint332(void){}
/* CAN7 transmit/receive FIFO receive complete interrupt; */
void eiint333(void){}
/* CAN7 transmit interrupt; */
void eiint334(void){}
/* Reserved; */
void eiint335(void){}
/* Reserved; */
void eiint336(void){}
/* Reserved; */
void eiint337(void){}
/* Reserved; */
void eiint338(void){}
/* Reserved; */
void eiint339(void){}
/* Reserved; */
void eiint340(void){}
/* Reserved; */
void eiint341(void){}
/* Reserved; */
void eiint342(void){}
/* Reserved; */
void eiint343(void){}
/* Reserved; */
void eiint344(void){}
/* Reserved; */
void eiint345(void){}
/* Reserved; */
void eiint346(void){}
/* Status interrupt for RSENT0; */
void eiint347(void){}
/* Receive interrupt for RSENT0; */
void eiint348(void){}
/* Status interrupt for RSENT1; */
void eiint349(void){}
/* Receive interrupt for RSENT1; */
void eiint350(void){}
/* Reserved; */
void eiint351(void){}
/* Reserved; */
void eiint352(void){}
/* Reserved; */
void eiint353(void){}
/* Reserved; */
void eiint354(void){}
/* Reserved; */
void eiint355(void){}
/* LPS0 digital port error interrupt; */
void eiint356(void){}
/* LPS0 analog port error interrupt; */
void eiint357(void){}
/* Reserved; */
void eiint358(void){}
/* Reserved; */
void eiint359(void){}
/* RLIN36 interrupt; */
void eiint360(void){}
/* RLIN36 transmit interrupt; */
void eiint361(void){}
/* RLIN36 receive complete interrupt; */
void eiint362(void){}
/* RLIN36 status interrupt; */
void eiint363(void){}
/* RLIN37 interrupt; */
void eiint364(void){}
/* RLIN37 transmit interrupt; */
void eiint365(void){}
/* RLIN37 receive complete interrupt; */
void eiint366(void){}
/* RLIN37 status interrupt; */
void eiint367(void){}
/* External interrupt; */
void eiint368(void){}
/* External interrupt; */
void eiint369(void){}
/* External interrupt; */
void eiint370(void){}
/* External interrupt; */
void eiint371(void){}
/* External interrupt; */
void eiint372(void){}
/* External interrupt; */
void eiint373(void){}
/* External interrupt; */
void eiint374(void){}
/* External interrupt; */
void eiint375(void){}
/* Interrupt for GRZF; */
void eiint376(void){}
