/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 *
 */

/***********************************************************************************************************************
* File Name    : Config_CAN0_user.c
* Version      : 1.3.0
* Device(s)    : R7F701650
* Description  : This file implements device driver for Config_CAN0.
***********************************************************************************************************************/
/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"
#include "Config_CAN_Transmission.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/

/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_CAN0_Create_UserInit
* Description  : This function adds user code after initializing CAN module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

// void R_Config_CAN0_Create_UserInit(void)
// {
//     /* Start user code for user init. Do not edit comment generated here */
//     /* End user code. Do not edit comment generated here */
// }

void R_Config_CAN0_Transmission_Create_UserInit(void){}
void R_Config_CAN1_Transmission_Create_UserInit(void){}
void R_Config_CAN2_Transmission_Create_UserInit(void){}
void R_Config_CAN3_Transmission_Create_UserInit(void){}
void R_Config_CAN4_Transmission_Create_UserInit(void){}
void R_Config_CAN5_Transmission_Create_UserInit(void){}
/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
