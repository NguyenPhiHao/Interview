/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 *
 */
 
/***********************************************************************************************************************
* File Name    : Config_CAN0.c
* Version      : 1.3.0
* Device(s)    : R7F701650
* Description  : This file implements device driver for Config_CAN0.
***********************************************************************************************************************/
/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_userdefine.h"
#include "Config_CAN_Transmission.h"
#include "Test_Environment.h"

/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/

// ET-VPF F1KM Product Version - V1.00.00 - Req. 02
// ID: ET_VPF_V1.00.00_CD_Req_02_014
// Reference: {ET_VPF_V1.00.00_UD_Req_02_001, ET_VPF_V1.00.00_UD_Req_02_002, ET_VPF_V1.00.00_UD_Req_02_003, ET_VPF_V1.00.00_UD_Req_02_004, ET_VPF_V1.00.00_UD_Req_02_005, ET_VPF_V1.00.00_UD_Req_02_006, ET_VPF_V1.00.00_UD_Req_02_007, ET_VPF_V1.00.00_UD_Req_02_008, ET_VPF_V1.00.00_UD_Req_02_009}

// Define the Transmission ID for each CAN unit
#define CAN0_SEND_ID 0
#define CAN1_SEND_ID 1
#define CAN2_SEND_ID 2
#define CAN3_SEND_ID 3
#define CAN4_SEND_ID 4
#define CAN5_SEND_ID 5
uint32_t CAN_Transmission_ID[6] = {CAN0_SEND_ID, CAN1_SEND_ID, CAN2_SEND_ID, CAN3_SEND_ID, CAN4_SEND_ID, CAN5_SEND_ID };
// Define is extended ID for each CAN unit
#define CAN0_Send_isExtID 0x0
#define CAN1_Send_isExtID 0x0
#define CAN2_Send_isExtID 0x0
#define CAN3_Send_isExtID 0x0
#define CAN4_Send_isExtID 0x0
#define CAN5_Send_isExtID 0x0

uint32_t CAN_Send_isExtID[6] = {CAN0_Send_isExtID, CAN1_Send_isExtID, CAN2_Send_isExtID, CAN3_Send_isExtID, CAN4_Send_isExtID, CAN5_Send_isExtID};
// Define is remote frame for each CAN unit
#define CAN0_Send_isremote 0x0
#define CAN1_Send_isremote 0x0
#define CAN2_Send_isremote 0x0
#define CAN3_Send_isremote 0x0
#define CAN4_Send_isremote 0x0
#define CAN5_Send_isremote 0x0

uint32_t CAN_Send_isRemote[6] = {CAN0_Send_isremote, CAN1_Send_isremote, CAN2_Send_isremote, CAN3_Send_isremote, CAN4_Send_isremote, CAN5_Send_isremote};

unsigned int GMemForSetPortRxControl = 0;
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */



/***********************************************************************************************************************
* Function Name: R_Config_CAN0_Transmission_Create
* Description  : This function initializes the Config_CAN0 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN0_Transmission_Create(void)
{
    /*Using P0_0 - CAN0TX - Alternative mode Out_2*/
    
    PORT.PMC0 |= SETBIT(0);
    PORT.PFCAE0 &= CLEARBIT(0);
    PORT.PFCE0 &= CLEARBIT(0);
    PORT.PFC0 |= SETBIT(0); 
    PORT.PM0 &= CLEARBIT(0);

    R_Config_CAN0_Transmission_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN1_Transmission_Create
* Description  : This function initializes the Config_CAN1 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN1_Transmission_Create(void)
{
    /*Using P0_3 - CAN1TX - Alternative mode Out_2*/
    
    PORT.PMC0 |= SETBIT(3);
    PORT.PFCAE0 &= CLEARBIT(3);
    PORT.PFCE0 &= CLEARBIT(3);
    PORT.PFC0 |= SETBIT(3);
    PORT.PM0 &= CLEARBIT(3);

    R_Config_CAN1_Transmission_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN2_Transmission_Create
* Description  : This function initializes the Config_CAN2 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN2_Transmission_Create(void)
{
    /*Using P0_4 - CAN2TX - Alternative mode Out_1*/
    
    PORT.PMC0 |= SETBIT(4);
    PORT.PFCAE0 &= CLEARBIT(4);
    PORT.PFCE0 &= CLEARBIT(4);
    PORT.PFC0 &= CLEARBIT(4);
    PORT.PM0 &= CLEARBIT(4);

    R_Config_CAN2_Transmission_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN3_Transmission_Create
* Description  : This function initializes the Config_CAN3 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN3_Transmission_Create(void)
{
    /*Using P0_8 - CAN3TX - Alternative mode Out_5*/
    
    PORT.PMC0 |= SETBIT(8);
    PORT.PFCAE0 |= SETBIT(8);
    PORT.PFCE0 &= CLEARBIT(8);
    PORT.PFC0 &= CLEARBIT(8);
    PORT.PM0 &= CLEARBIT(8);

    R_Config_CAN3_Transmission_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN4_Transmission_Create
* Description  : This function initializes the Config_CAN4 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN4_Transmission_Create(void)
{
    /*Using P0_10 - CAN4TX - Alternative mode Out_5*/
    
    PORT.PMC0 |= SETBIT(10);
    PORT.PFCAE0 |= SETBIT(10);
    PORT.PFCE0 &= CLEARBIT(10);
    PORT.PFC0 &= CLEARBIT(10);
    PORT.PM0 &= CLEARBIT(10);

    R_Config_CAN4_Transmission_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN5_Transmission_Create
* Description  : This function initializes the Config_CAN5 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN5_Transmission_Create(void)
{
    /*Using P0_14 - CAN5TX - Alternative mode Out_5*/
    
    PORT.PMC0 |= SETBIT(14);
    PORT.PFCAE0 |= SETBIT(14);
    PORT.PFCE0 &= CLEARBIT(14);
    PORT.PFC0 &= CLEARBIT(14);
    PORT.PM0 &= CLEARBIT(14);

    R_Config_CAN5_Transmission_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN0_Transmission_Start
* Description  : This function starts the Config_CAN0 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN0_Transmission_Start(void)
{
    /*Change to communication mode*/
    RCFDC0.CFDC0CTR.UINT32 = CAN_CHANNEL_COMMUNICATION_MODE;
    while ((RCFDC0.CFDC0STS.UINT32 & 0x80) == 0x0);
    
    // Using classical CAN 
    RCFDC0.CFDC0FDCFG.UINT32 = CAN_CLASSICAL_CAN;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN1_Transmission_Start
* Description  : This function starts the Config_CAN1 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN1_Transmission_Start(void)
{
    /*Change to communication mode*/
    RCFDC0.CFDC1CTR.UINT32 = CAN_CHANNEL_COMMUNICATION_MODE;
    while ((RCFDC0.CFDC1STS.UINT32 & 0x80) == 0x0);
    
    // Using classical CAN 
    RCFDC0.CFDC1FDCFG.UINT32 = CAN_CLASSICAL_CAN;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN2_Transmission_Start
* Description  : This function starts the Config_CAN2 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN2_Transmission_Start(void)
{
    /*Change to communication mode*/
    RCFDC0.CFDC2CTR.UINT32 = CAN_CHANNEL_COMMUNICATION_MODE;
    while ((RCFDC0.CFDC2STS.UINT32 & 0x80) == 0x0);
    
    // Using classical CAN 
    RCFDC0.CFDC2FDCFG.UINT32 = CAN_CLASSICAL_CAN;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN3_Transmission_Start
* Description  : This function starts the Config_CAN3 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN3_Transmission_Start(void)
{
    /*Change to communication mode*/
    RCFDC0.CFDC3CTR.UINT32 = CAN_CHANNEL_COMMUNICATION_MODE;
    while ((RCFDC0.CFDC3STS.UINT32 & 0x80) == 0x0);
    
    // Using classical CAN 
    RCFDC0.CFDC3FDCFG.UINT32 = CAN_CLASSICAL_CAN;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN4_Transmission_Start
* Description  : This function starts the Config_CAN4 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN4_Transmission_Start(void)
{
    /*Change to communication mode*/
    RCFDC0.CFDC4CTR.UINT32 = CAN_CHANNEL_COMMUNICATION_MODE;
    while ((RCFDC0.CFDC4STS.UINT32 & 0x80) == 0x0);
    
    // Using classical CAN 
    RCFDC0.CFDC4FDCFG.UINT32 = CAN_CLASSICAL_CAN;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN5_Transmission_Start
* Description  : This function starts the Config_CAN5 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN5_Transmission_Start(void)
{
    /*Change to communication mode*/
    RCFDC0.CFDC5CTR.UINT32 = CAN_CHANNEL_COMMUNICATION_MODE;
    while ((RCFDC0.CFDC5STS.UINT32 & 0x80) == 0x0);
    
    // Using classical CAN 
    RCFDC0.CFDC5FDCFG.UINT32 = CAN_CLASSICAL_CAN;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN0_Transmission_Stop
* Description  : This function stops the CAN0 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN0_Transmission_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC0CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN1_Transmission_Stop
* Description  : This function stops the CAN1 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN1_Transmission_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC1CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN2_Transmission_Stop
* Description  : This function stops the CAN2 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN2_Transmission_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC2CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN3_Transmission_Stop
* Description  : This function stops the CAN3 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN3_Transmission_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC3CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN4_Transmission_Stop
* Description  : This function stops the CAN4 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN4_Transmission_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC4CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}


/***********************************************************************************************************************
* Function Name: R_Config_CAN5_Transmission_Stop
* Description  : This function stops the CAN5 module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_CAN5_Transmission_Stop(void)
{
    /*Change to stop mode*/
    RCFDC0.CFDC5CTR.UINT32 = CAN_CHANNEL_STOP_MODE;
}

/***********************************************************************************************************************
* Function Name: R_Config_CAN_Transmission_Send
* Description  : This function sends CAN data.
* Arguments    :  unit, channel, inputData
* Return Value : None
***********************************************************************************************************************/
MD_STATUS R_Config_CAN_Transmission_Send(char unit, char channel,const uint8_T* inputData, int_T msglength)
{
    volatile long lowerData;
    volatile long upperData;
    int i;

    /***** Prepare the buffer ******/
    RCFDCnCFDTMIDp(channel*32) = CAN_Transmission_ID[channel] | CAN_Send_isExtID[channel] <<31 | CAN_Send_isRemote[channel]<<30;// ID   
    RCFDCnCFDTMPTRp(channel*32) = 0x00000000 | (msglength<<28);
    
    RCFDCnCFDTMFDCTRp(channel*32) =  0x0;        // using clasical CAN

    if (!CAN_Send_isRemote[channel])
    {
        lowerData = 0;
        upperData = 0;
        if (msglength > 4){
            // for lower data
            for (i = 3; i>= 0; i--){
                lowerData = lowerData << 8 | inputData[i];
            }

            // for upper data
            for (i = msglength -1 ; i >=4; i--){
                upperData = upperData << 8 | inputData[i];
            }
            RCFDCnCFDTMDFb_p(0,channel*32) = lowerData;
            RCFDCnCFDTMDFb_p(1,channel*32) = upperData;
        }  
        else{
            // for lower data
            for (i = msglength-1; i>= 0; i--){
                lowerData = lowerData << 8 | inputData[i];
            }
            RCFDCnCFDTMDFb_p(0,channel*32) = lowerData;
        }
    }
    /***** Send from the buffer ***/
    RCFDCnCFDTMC(channel*32) = 0x1;              // Trigger for sending, TMTR = 1

    while (0 == (RCFDCnCFDTMSTSp(channel*32)&0x1));
    GMemForSetPortRxControl = (unsigned int)channel;
    while (0 == (RCFDCnCFDTMSTSp(channel*32)&0x6));
    RCFDCnCFDTMSTSp(channel*32) = 0;
    return 0;
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
// ET-VPF F1KM Product Version - V1.00.00 - Req. 02 - End
