/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 *
 */
 
/***********************************************************************************************************************
* File Name    : Config_UART0.h
* Version      : 1.3.0
* Device(s)    : R7F701650
* Description  : This file implements device driver for Config_UART0.
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_can.h"
#include "r_cg_macrodriver.h"
#include "rtwtypes.h"
#include "iodefine.h"

#ifndef CFG_Config_CAN0_Transmission_H
#define CFG_Config_CAN0_Transmission_H

extern unsigned int GMemForSetPortRxControl;
/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void CAN_Common_Transmission_Init(void);
void CAN_Common_operating_Init(void);
void R_Config_CAN0_Transmission_Create(void);
void R_Config_CAN1_Transmission_Create(void);
void R_Config_CAN2_Transmission_Create(void);
void R_Config_CAN3_Transmission_Create(void);
void R_Config_CAN4_Transmission_Create(void);
void R_Config_CAN5_Transmission_Create(void);
void R_Config_CAN0_Transmission_Start(void);
void R_Config_CAN1_Transmission_Start(void);
void R_Config_CAN2_Transmission_Start(void);
void R_Config_CAN3_Transmission_Start(void);
void R_Config_CAN4_Transmission_Start(void);
void R_Config_CAN5_Transmission_Start(void);

void R_Config_CAN0_Transmission_Stop(void);
void R_Config_CAN1_Transmission_Stop(void);
void R_Config_CAN2_Transmission_Stop(void);
void R_Config_CAN3_Transmission_Stop(void);
void R_Config_CAN4_Transmission_Stop(void);
void R_Config_CAN5_Transmission_Stop(void);

void R_Config_CAN0_Transmission_Create_UserInit(void);
void R_Config_CAN1_Transmission_Create_UserInit(void);
void R_Config_CAN2_Transmission_Create_UserInit(void);
void R_Config_CAN3_Transmission_Create_UserInit(void);
void R_Config_CAN4_Transmission_Create_UserInit(void);
void R_Config_CAN5_Transmission_Create_UserInit(void);

MD_STATUS R_Config_CAN_Transmission_Send(char unit, char channel, const uint8_T* inputData, int_T msglength);
/* Start user code for function. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#endif
