/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 *
 */
 
/***********************************************************************************************************************
* File Name    : r_cg_uart.h
* Version      : 1.0.101
* Device(s)    : R7F702300EBBG
* Description  : General header file for UART peripheral.
***********************************************************************************************************************/

#ifndef CAN_H
#define CAN_H

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/
#define CLEARBIT(x)   ~(1U<<x)
#define SETBIT(x)     (1U << x)

#define CAN_CHANNEL_COMMUNICATION_MODE    0x0
#define CAN_CHANNEL_STOP_MODE             0x4

#define CAN_CLASSICAL_CAN               0x40000000


// CAN
#define RCFDCn_base 0xFFD00000
// Trigger register for transmission.
#define RCFDCnCFDTMC(p)    (*((volatile unsigned long *)(RCFDCn_base + 0x0250 + p*0x01)))

//Setting ID register for CAN message
#define RCFDCnCFDTMIDp(p)    (*((volatile unsigned long *)(RCFDCn_base + 0x8000 + p*0x80)))

//Transmit buffer pointer register
#define RCFDCnCFDTMPTRp(p)    (*((volatile unsigned long *)(RCFDCn_base + 0x8004 + p*0x80)))
//Transmit buffer CAN FD configuration register
#define RCFDCnCFDTMFDCTRp(p)    (*((volatile unsigned long *)(RCFDCn_base + 0x8008 + p*0x80)))

//Transmit buffer data field register
#define RCFDCnCFDTMDFb_p(b,p)    (*((volatile unsigned long *)(RCFDCn_base + 0x800C + 0x04*b+ p*0x80)))

//Status register
#define RCFDCnCFDTMSTSp(p)    (*((volatile unsigned char *)(RCFDCn_base + 0x0350 + p*0x1)))

// Global status register
#define RCFDCnCFDGSTS    (*((volatile unsigned long *)(RCFDCn_base + 0x008C)))

// Global control register
#define RCFDCnCFDGCTR    (*((volatile unsigned long *)(RCFDCn_base + 0x0088)))

// Receive rule configuration register 0
#define RCFDCnCFDGAFLCFG0    (*((volatile unsigned long *)(RCFDCn_base + 0x009C)))

// Receive rule configuration register 1
#define RCFDCnCFDGAFLCFG1    (*((volatile unsigned long *)(RCFDCn_base + 0x00A0)))

// /*
//     UART Error Clear Flag Macro Definition
// */
// #define _UART_CLEAR_ERROR_FLAG                      (0x7D)

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void CAN_Common_Init(void);
void CAN_Common_operating_Init(void);
/* Start user code for function. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#endif
