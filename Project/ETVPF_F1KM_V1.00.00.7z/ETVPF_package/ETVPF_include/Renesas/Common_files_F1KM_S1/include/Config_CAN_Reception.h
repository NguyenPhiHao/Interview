/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 *
 */

/***********************************************************************************************************************
* File Name    : Config_UART0.h
* Version      : 1.3.0
* Device(s)    : R7F701650
* Description  : This file implements device driver for Config_UART0.
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_can.h"
#include "iodefine.h"
#include "r_cg_macrodriver.h"

#ifndef CFG_Config_CAN0_Reception_H
#define CFG_Config_CAN0_Reception_H

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void CAN_Common_Reception_Init(void);
void R_Config_CAN0_Reception_Create(void);
void R_Config_CAN1_Reception_Create(void);
void R_Config_CAN2_Reception_Create(void);
void R_Config_CAN3_Reception_Create(void);
void R_Config_CAN4_Reception_Create(void);
void R_Config_CAN5_Reception_Create(void);

void R_Config_CAN0_Reception_Start(void);
void R_Config_CAN1_Reception_Start(void);
void R_Config_CAN2_Reception_Start(void);
void R_Config_CAN3_Reception_Start(void);
void R_Config_CAN4_Reception_Start(void);
void R_Config_CAN5_Reception_Start(void);

void R_Config_CAN0_Reception_Stop(void);
void R_Config_CAN1_Reception_Stop(void);
void R_Config_CAN2_Reception_Stop(void);
void R_Config_CAN3_Reception_Stop(void);
void R_Config_CAN4_Reception_Stop(void);
void R_Config_CAN5_Reception_Stop(void);

void R_Config_CAN0_Reception_Create_UserInit(void);
void R_Config_CAN1_Reception_Create_UserInit(void);
void R_Config_CAN2_Reception_Create_UserInit(void);
void R_Config_CAN3_Reception_Create_UserInit(void);
void R_Config_CAN4_Reception_Create_UserInit(void);
void R_Config_CAN5_Reception_Create_UserInit(void);

MD_STATUS R_Config_CAN_Receive( char unit,char channel, uint8_t * output);
/* Start user code for function. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#endif
