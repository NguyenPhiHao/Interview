/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */
 
/*
 * Include Files
 *
 */
#if defined(MATLAB_MEX_FILE)
#include "tmwtypes.h"
#include "simstruc_types.h"
#else
#include "rtwtypes.h"
#endif

#include "iodefine.h"
#include "r_cg_macrodriver.h"
#include "Test_Environment.h"

/* %%%-SFUNWIZ_wrapper_includes_Changes_BEGIN --- EDIT HERE TO _END */
#include <math.h>
/* %%%-SFUNWIZ_wrapper_includes_Changes_END --- EDIT HERE TO _BEGIN */
#define u_width 1
#define y_width 1

/*
 * Create external references here.  
 *
 */
/* %%%-SFUNWIZ_wrapper_externs_Changes_BEGIN --- EDIT HERE TO _END */
/* extern double func(double a); */
/* %%%-SFUNWIZ_wrapper_externs_Changes_END --- EDIT HERE TO _BEGIN */

/*
 * Output functions
 *
 */
void get_ADC_data_Outputs_wrapper(const real_T *u0,
			real_T *y0,
			const real_T *unit, const int_T p_width0,
			const real_T *max_vcr_channel, const int_T p_width1,
			const real_T *portID, const int_T p_width2)
{
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_BEGIN --- EDIT HERE TO _END */
# ifdef ETVPF
    // Generated source code
    char unit_ = (char)*unit;
    char max_vcr_channel_ = (char)*max_vcr_channel;
    char portID_ = (char)*portID;
    // Get_adc_data(y0, unit_, max_vcr_channel_, portID_);
    int n,index;
    uint32_t start_pointer, end_pointer, count;
    uint32_t *addr, virtualchannel;
    start_pointer = (uint8_t) ADCA0.SGVCSP1.UINT32;
    end_pointer = (uint8_t) ADCA0.SGVCEP1.UINT32;
    volatile const uint32_t count_num = end_pointer - start_pointer + 1U;
    
    int vir_channel_arr[MAX_VIRTUAL_CHANNEL] = {0};
    uint16_t ADCA0_conversion_val[MAX_VIRTUAL_CHANNEL] = {0}; 
    uint16_t *ADCA0_buffer = (uint16_t*) &ADCA0_conversion_val;
    uint16_t ADCA1_conversion_val[MAX_VIRTUAL_CHANNEL] = {0}; 
    uint16_t *ADCA1_buffer = (uint16_t*) &ADCA1_conversion_val;
    float inputVol = 0;
    addr = (uint32_t*)(0xFFF20000UL + start_pointer * 4U);

    // Create array of virtual channel exist
    for (count = 0U; count < count_num; count++)
    {
        // Get virtual channel name of ADCJ0.VCR(count)
        virtualchannel = (uint32_t)*addr & 0x3F;

        // Put index virtual channel of ADCJ0.VCR(count) to array of virtual channel
        for (n = 0; n < 36; n++)
        {
            if (virtualchannel == n)
            {
                vir_channel_arr[count]=n;
                break;
            }
        }
        addr++;
    }

    // Find the index buffer of physical channel adapt with array virtual channel
    for (int i = 0; i < count_num; i++)
    {
        if(portID_ == vir_channel_arr[i])
        {
            index = i;
            break;
        }
    }

    Config_ADC_ScanGroup1_OperationOn(unit_);
    Wait_For_Conversion(unit_);
    Config_ADC_ScanGroup1_GetResult(unit_, ADCA0_buffer, ADCA1_buffer);
    
    // Get inputVol of current physical channel
    inputVol = ((float) ((unsigned int) (ADCA0_conversion_val[index]) * 3.3))/4095;
    *y0 = inputVol;
# else
    // Execute on MATLAB
    y0[0] = u0[0];
# endif
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_END --- EDIT HERE TO _BEGIN */
}


