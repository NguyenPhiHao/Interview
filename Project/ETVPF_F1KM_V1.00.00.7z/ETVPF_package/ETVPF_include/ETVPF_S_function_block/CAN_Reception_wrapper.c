
/*
 * Copyright(C) 2022 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */
 
/*
 * Include Files
 *
 */
// ET-VPF F1KM Product Version - V1.00.00 - Req. 02
// ID: ET_VPF_V1.00.00_CD_Req_02_018
// Reference: {ET_VPF_V1.00.00_UD_Req_02_001, ET_VPF_V1.00.00_UD_Req_02_002, ET_VPF_V1.00.00_UD_Req_02_003, ET_VPF_V1.00.00_UD_Req_02_004, ET_VPF_V1.00.00_UD_Req_02_005, ET_VPF_V1.00.00_UD_Req_02_006, ET_VPF_V1.00.00_UD_Req_02_007, ET_VPF_V1.00.00_UD_Req_02_008, ET_VPF_V1.00.00_UD_Req_02_009}
#if defined(MATLAB_MEX_FILE)
#include "tmwtypes.h"
#include "simstruc_types.h"
#else
#include "rtwtypes.h"
#endif



/* %%%-SFUNWIZ_wrapper_includes_Changes_BEGIN --- EDIT HERE TO _END */
# ifdef ETVPF
#include "Config_CAN_Reception.h"
# endif
/* %%%-SFUNWIZ_wrapper_includes_Changes_END --- EDIT HERE TO _BEGIN */

/*
 * Create external references here.  
 *
 */
/* %%%-SFUNWIZ_wrapper_externs_Changes_BEGIN --- EDIT HERE TO _END */
 
/* %%%-SFUNWIZ_wrapper_externs_Changes_END --- EDIT HERE TO _BEGIN */

/*
 * Output functions
 *
 */
void CAN_Reception_Outputs_wrapper(const uint8_T *u0,
			uint8_T *y0,
			const real_T *can_unit, const int_T p_width0,
			const real_T *can_channel, const int_T p_width1,
			const int_T y_width,
			const int_T u_width)
{
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_BEGIN --- EDIT HERE TO _END */
# ifdef ETVPF
    char unit_ = (char)*can_unit;
    char channel_ = (char) *can_channel;
    // Generated source code
    R_Config_CAN_Receive(unit_, channel_, y0);
# else
    // Execute on MATLAB
    for (int i = 0; i < y_width; i++) // y_width is same as u_width
    {
        y0[i] = u0[i];
    }
# endif
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_END --- EDIT HERE TO _BEGIN */
}

// ET-VPF F1KM Product Version - V1.00.00 - Req. 02 - End
